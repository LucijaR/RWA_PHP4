<!DOCTYPE html>
<html lang="hr">
<head>

 <meta charset="UTF-8" />
 <title>Varijable</title>
 
</head>

<body>
<?php
class Klasa1 
{
    private $privatnoime;
    public $javnoime;
    protected $zasticenoime;

    public function __construct($javni, $zasticeni, $privatni) 
	{
        $this->javnoime = $javni;
        $this->zasticenoime = $zasticeni;
        $this->privatnoime = $privatni;
    }
    private function ispisPrivatnog() 
	{
        echo "Privatno ime: {$this->privatnoime}<br>";
    }
    public function ispisJavnog() 
	{
        echo "Javno ime: {$this->javnoime}<br>";
    }

    protected function ispisZasticenog() 
	{
        echo "Zasticeno ime: {$this->zasticenoime}<br>";
    }


    public function ispis() 
	{
        $this->ispisJavnog();
        $this->ispisZasticenog();
        $this->ispisPrivatnog();
    }

    public function spojeniAtributi() {
        echo "Spojena imena: {$this->privatnoime} {$this->zasticenoime}<br>";
    }
}

$objekt = new Klasa1("Nikola", "Mateo", "Ante");
$objekt->ispis();
$objekt->spojeniAtributi();

?>
 
</body>
</html>