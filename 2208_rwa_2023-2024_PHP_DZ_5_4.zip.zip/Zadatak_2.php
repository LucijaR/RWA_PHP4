<!DOCTYPE html>
<html lang="hr">
<head>

 <meta charset="UTF-8" />
 <title>Varijable</title>
 
</head>

<body>
<?php
class Test
{
    public $ime;
    public $prezime;
    public $ostvareniBodovi;
    public $maxBodovi;
    public $ocjena;

    public function __construct($ime, $prezime, $ostvareniBodovi, $maxBodovi) 
	{
        $this->ime = $ime;
        $this->prezime = $prezime;
        $this->ostvareniBodovi = $ostvareniBodovi;
        $this->maxBodovi = $maxBodovi;
        $this->izracunajOcjenu();
    }

    private function izracunajOcjenu() 
	{
        if ($this->maxBodovi > 0)
		{
            $postotak = ($this->ostvareniBodovi / $this->maxBodovi) * 100;
            if ($postotak >= 90) 
			{
                $this->ocjena = 'A';
            }
			elseif ($postotak >= 80)
			{
                $this->ocjena = 'B';
            } 
			elseif ($postotak >= 70) 
			{
                $this->ocjena = 'C';
            } 
			elseif ($postotak >= 60) 
			{
                $this->ocjena = 'D';
            }
			else 
			{
                $this->ocjena = 'F';
            }
        } else 
		{
            $this->ocjena = 'Nije ocijenjeno';
        }
    }
}
$test1 = new Test("Mate", "Matic", 68, 99);
$test2 = new Test("Marta", "Martic", 70, 90);
$test3 = new Test("Luka", "Lukic", 88, 100);
$test4 = new Test("Ivo", "Ivic", 99, 100);


echo "Ocjena {$test1->ocjena}<br>";
echo "Ocjena {$test2->ocjena}<br>";
echo "Ocjena {$test3->ocjena}<br>";
echo "Ocjena {$test4->ocjena}<br>";

?>
 
</body>
</html>