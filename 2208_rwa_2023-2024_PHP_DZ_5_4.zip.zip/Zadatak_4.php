<!DOCTYPE html>
<html lang="hr">
<head>

 <meta charset="UTF-8" />
 <title>Varijable</title>
 
</head>

<body>
<?php

class Kalkulator 
{
    private $rezultat;

    public function __construct() 
	{
        $this->rezultat = 0;
    }

    public function zbroji($broj) 
	{
        $this->rezultat += $broj;
    }

    public function oduzmi($broj) 
	{
        $this->rezultat -= $broj;
    }

    public function pomnozi($broj) 
	{
        $this->rezultat *= $broj;
    }

    public function podijeli($broj) 
	{
        $this->rezultat /= $broj;
        
    }

    public function dohvatiRezultat() 
	{
        return $this->rezultat;
    }
}
$kalkulator = new Kalkulator();

$kalkulator->zbroji(89);
$kalkulator->oduzmi(37);
$kalkulator->pomnozi(1);
$kalkulator->podijeli(2);

print("Rezultat: " . $kalkulator->dohvatiRezultat());

?>
 
</body>
</html>