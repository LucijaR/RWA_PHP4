<head>

 <meta charset="UTF-8" />
 <title>Varijable</title>
 
</head>

<body>
<?php
class Person 
{
    public $ime;
    public $prezime;
    public $masaKg;

    public function __construct($ime, $prezime, $masaKg) 
	{
        $this->ime = $ime;
        $this->prezime = $prezime;
        $this->masaKg = $masaKg;
    }

    public function ispisiTezinu() 
	{
        echo "{$this->ime} {$this->prezime} - težina: {$this->masaKg} kg.<br>";
    }

    public function tezinaNaMjesecu()
	{
        $tezinaNaMjesecu = $this->masaKg * (1.625 / 9.8);
        return $tezinaNaMjesecu;
    }

    public function ispisiTezinuNaMjesecu() 
	{
        $tezinaMjesec = $this->tezinaNaMjesecu();
        echo "{$this->ime} {$this->prezime} - težina na mjesecu: {$tezinaMjesec} .<br>";
    }
}
$osoba1 = new Person("Mateo","Matic",89);
$osoba2 = new Person("Iva", "Ivic", 50);
$osoba3 = new Person("Matija", "Matic", 61);
$osoba4 = new Person("Marko", "Markic", 99);

$osoba1->ispisiTezinu();
$osoba1->ispisiTezinuNaMjesecu();

$osoba2->ispisiTezinu();
$osoba2->ispisiTezinuNaMjesecu();

$osoba3->ispisiTezinu();
$osoba3->ispisiTezinuNaMjesecu();

$osoba4->ispisiTezinu();
$osoba4->ispisiTezinuNaMjesecu();
?>
 
</body>
</html>